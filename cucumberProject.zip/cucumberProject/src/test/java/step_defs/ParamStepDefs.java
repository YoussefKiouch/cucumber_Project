package step_defs;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ParamStepDefs {
    @Given("^User \"([^\"]*)\" with password \"([^\"]*)\" is registered$")
    public void user_with_password_is_registered(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @When("^User \"([^\"]*)\" with password \"([^\"]*)\" logs in$")
    public void user_with_password_logs_in(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("^User \"([^\"]*)\" should be navigated to Homepage$")
    public void user_should_be_navigated_to_Homepage(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }
}
